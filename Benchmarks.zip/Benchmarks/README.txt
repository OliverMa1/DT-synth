Z3_SCRIPT_PATH contains php files

