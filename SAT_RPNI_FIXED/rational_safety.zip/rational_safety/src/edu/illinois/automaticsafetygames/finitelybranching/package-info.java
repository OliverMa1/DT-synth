/**
 * Teacher and learner for automatic safety games over <em>finitely branching</em> automatic arenas.
 * 
 * @author Daniel Neider
 *
 */
package edu.illinois.automaticsafetygames.finitelybranching;