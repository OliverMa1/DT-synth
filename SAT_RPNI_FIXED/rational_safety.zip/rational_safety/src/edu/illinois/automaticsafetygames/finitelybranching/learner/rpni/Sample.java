package edu.illinois.automaticsafetygames.finitelybranching.learner.rpni;

import java.util.HashSet;

public class Sample {
    public HashSet<String> content = new HashSet<String>();
}