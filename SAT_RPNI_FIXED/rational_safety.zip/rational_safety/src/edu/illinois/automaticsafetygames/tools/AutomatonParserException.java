package edu.illinois.automaticsafetygames.tools;

public class AutomatonParserException extends Exception {

	/**
	 * Version ID
	 */
	private static final long serialVersionUID = -1200554119929432705L;

	public AutomatonParserException(String msg) {
		super(msg);
	}

}
