package edu.illinois.automaticsafetygames.games.examples;

public class DiagonalGameUnlimited {
}
