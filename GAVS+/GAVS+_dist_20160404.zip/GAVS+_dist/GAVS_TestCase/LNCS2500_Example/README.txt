NOTICE

When executing the parity game solver with the example
LNCS2500_Fig_6_1.mxe, the solver jumps back and forth between
two valuations and never stop. It seems to be some corner cases 
which is not explicitly specified in the algorithm. I am now 
trying to fix this bug.

Sincerely,
Chih-Hong Cheng