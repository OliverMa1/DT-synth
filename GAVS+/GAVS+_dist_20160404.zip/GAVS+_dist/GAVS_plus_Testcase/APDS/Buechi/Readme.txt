In this version, we follow the algorithm of T. Cachat in ICALP'02,
meaning that for games satisfying the Buechi condition, currently 
the engine solves a restricted form (although it is equivalent to the general form).
For details, please see the paper.

Under this setting, for the goal configuration {P}, this means the set of
all configurations which has states starting with P, i.e., P {alphabet set}^*.

We will release this constraint in our next version.

Chihhong
20101005
